from rest_framework import serializers
from .models import *

class StudentSerializer(serializers.ModelSerializer):
    student_id = serializers.SerializerMethodField()

    class Meta:
        model = Student
        fields = '__all__'

    def get_student_id(self, obj):
        return obj.student_id.student_id  
        
class UniSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = uni
        fields = '__all__'    
        
class DepSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Department
        fields = '__all__'  
        
class Subject_Marks_Serializer(serializers.ModelSerializer):
    
    class Meta:
        model = Subject_Marks
        fields = '__all__'   
        
class ReportCard_Serializer(serializers.ModelSerializer):
    
    class Meta:
        model = ReportCard
        fields = '__all__'   